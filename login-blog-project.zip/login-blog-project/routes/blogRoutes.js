const express = require('express');
const Blog = require('../models/Blog'); // Import the Blog model
const router = express.Router();

// Fetch All Blogs
router.get('/', async (req, res) => {
    try {
        const blogs = await Blog.find().populate('author', 'name'); // Populate author name
        // res.render('index', { user: req.user || null, blogs: blogs });
        res.render('blog/index', { user: req.user || null, blogs: blogs });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

// Create Blog Form
router.get('/new', (req, res) => {
    res.render('blog/new');
});

// Create New Blog
router.post('/', async (req, res) => {
    try {
        const { title, content } = req.body;
        const author = req.user._id; // Assuming req.user contains the authenticated user
        const blog = new Blog({ title, content, author });
        await blog.save();
        res.redirect('/blogs');
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

// Fetch Single Blog
router.get('/:id', async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id).populate('author', 'name');
        if (!blog) {
            return res.status(404).send('Blog not found');
        }
        res.render('blog/show', { blog });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

module.exports = router;
