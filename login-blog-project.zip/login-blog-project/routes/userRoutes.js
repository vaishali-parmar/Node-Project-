const express = require('express');
const {
    getAllUsers,
    getUserById,
    updateUser,
    deleteUser,
} = require('../controllers/userController');
const authMiddleware = require('../middlewares/authMiddleware');
const roleMiddleware = require('../middlewares/roleMiddleware');

const router = express.Router();

// Get all users (Admin only)
router.get('/', authMiddleware, roleMiddleware('admin'), getAllUsers);

// Get a single user by ID (Admin or the user themselves)
router.get('/:id', authMiddleware, getUserById);

// Update user profile (Admin or the user themselves)
router.put('/:id', authMiddleware, updateUser);

// Delete a user (Admin only)
router.delete('/:id', authMiddleware, roleMiddleware('admin'), deleteUser);

module.exports = router;
