const http = require('http');
const routes = require('./routes');

const PORT = 3000;

// Create the server
const server = http.createServer((req, res) => {
  const { url, method } = req;

  // Log incoming requests
  console.log(`Incoming Request: ${method} ${url}`);

  // Handle routes
  if (routes[url] && routes[url][method]) {
    routes[url][method](req, res);
  } else {
    routes['/404']['GET'](req, res);
  }
});

// Start the server
server.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
