const express = require('express');
const bodyParser = require('body-parser');
const connectDB = require('./config/db.config');
const bookRoutes = require('./routes/book.routes');
const swaggerJsDoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');
require('dotenv').config();

const app = express();

// Connect to MongoDB
connectDB();

// Middleware
app.use(bodyParser.json());

// Swagger Configuration
const swaggerOptions = {
    swaggerDefinition: {
        openapi: '3.0.0',
        info: {
            title: 'Book Store API',
            version: '1.0.0',
            description: 'API for managing books, authors, and categories',
            contact: {
                name: 'API Support',
                email: 'support@bookstoreapi.com'
            },
            servers: [{ url: `http://localhost:${process.env.PORT || 5000}` }]
        }
    },
    apis: ['./src/routes/*.js'], // Points to the files with documentation
};
const swaggerDocs = swaggerJsDoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Routes
app.use('/api/books', bookRoutes);

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
