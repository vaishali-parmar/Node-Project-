const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Serve static files (CSS, images, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Dynamic content for each route
const content = {
  index: {
    title: 'Home Page',
    heading: 'Welcome to My Website',
    description: 'This is the home page served using Node.js with EJS templating.',
  },
  about: {
    title: 'About Us',
    heading: 'About Us',
    description: 'Learn more about us and our mission.',
  },
  contact: {
    title: 'Contact Us',
    heading: 'Contact Us',
    description: 'Reach out to us through the form below.',
  },
};

// Routes
app.get('/', (req, res) => {
  res.render('index', content.index);
});

app.get('/about', (req, res) => {
  res.render('about', content.about);
});

app.get('/contact', (req, res) => {
  res.render('contact', content.contact);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
