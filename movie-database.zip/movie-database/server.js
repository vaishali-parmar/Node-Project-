const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static('public')); // For serving static files

// OMDb API Key
const OMDB_API_KEY = '55ff1fde';  // Replace with your OMDb API Key

// Dummy database to store movie details (in-memory for simplicity)
let movieDatabase = [];

// Routes

// Home page: Display list of movies
app.get('/', (req, res) => {
  res.render('index', { movies: movieDatabase });
});

// Add Movie page
app.get('/add-movie', (req, res) => {
  res.render('add-movie');
});

// Submit movie name to fetch details from OMDb API and add to the database
app.post('/add-movie', async (req, res) => {
  const { movieName } = req.body;

  if (!movieName) {
    return res.status(400).send('Movie name is required');
  }

  try {
    // Fetch movie details from OMDb
    const response = await axios.get(`http://www.omdbapi.com/?t=${movieName}&apikey=${OMDB_API_KEY}`);
    const movieData = response.data;

    if (movieData.Response === 'False') {
      return res.status(404).send('Movie not found');
    }

    // Add movie to the "database"
    const movie = {
      title: movieData.Title,
      year: movieData.Year,
      plot: movieData.Plot,
      poster: movieData.Poster,
    };
    movieDatabase.push(movie);

    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error fetching movie details');
  }
});

// Update movie details
app.get('/update-movie/:title', (req, res) => {
  const { title } = req.params;
  const movie = movieDatabase.find(movie => movie.title.toLowerCase() === title.toLowerCase());

  if (movie) {
    res.render('update-movie', { movie });
  } else {
    res.status(404).send('Movie not found');
  }
});

// Handle movie update
app.post('/update-movie/:title', (req, res) => {
  const { title } = req.params;
  const { updatedTitle, updatedYear, updatedPlot } = req.body;

  const movie = movieDatabase.find(movie => movie.title.toLowerCase() === title.toLowerCase());

  if (movie) {
    movie.title = updatedTitle || movie.title;
    movie.year = updatedYear || movie.year;
    movie.plot = updatedPlot || movie.plot;
    res.redirect('/');
  } else {
    res.status(404).send('Movie not found');
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
