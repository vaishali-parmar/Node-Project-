const express = require('express');
const Blog = require('../models/Blog');
const User = require('../models/User');
const router = express.Router();

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
  if (!req.cookies.auth_token) {
    return res.redirect('/login');
  }
  jwt.verify(req.cookies.auth_token, 'your-secret-key', (err, decoded) => {
    if (err) {
      return res.redirect('/login');
    }
    req.user = decoded;
    next();
  });
}

// Create a new blog post
router.post('/create-post', isAuthenticated, async (req, res) => {
  const { title, content } = req.body;
  const blog = new Blog({ title, content, author: req.user.id });
  await blog.save();
  res.redirect('/');
});

// Edit a blog post
router.get('/edit-post/:id', isAuthenticated, async (req, res) => {
  const blog = await Blog.findById(req.params.id);
  if (blog.author.toString() !== req.user.id.toString()) {
    return res.status(403).send('Unauthorized');
  }
  res.render('edit-post', { blog });
});

// Update blog post
router.post('/edit-post/:id', isAuthenticated, async (req, res) => {
  const { title, content } = req.body;
  const blog = await Blog.findById(req.params.id);
  if (blog.author.toString() !== req.user.id.toString()) {
    return res.status(403).send('Unauthorized');
  }

  blog.title = title;
  blog.content = content;
  await blog.save();
  res.redirect('/');
});

// Delete a blog post
router.get('/delete-post/:id', isAuthenticated, async (req, res) => {
  const blog = await Blog.findById(req.params.id);
  if (blog.author.toString() !== req.user.id.toString()) {
    return res.status(403).send('Unauthorized');
  }

  await blog.remove();
  res.redirect('/');
});

module.exports = router;
