const taskForm = document.getElementById('task-form');
const taskInput = document.getElementById('task-input');
const taskList = document.getElementById('task-list');

let editMode = false; // Track whether we're in edit mode
let editTaskId = null; // Track the task being edited

// Fetch and display tasks
const loadTasks = async () => {
  const response = await fetch('/api/tasks');
  const tasks = await response.json();
  taskList.innerHTML = '';
  tasks.forEach((task) => {
    const li = document.createElement('li');
    li.innerHTML = `
      ${task.completed ? `<s>${task.description}</s>` : task.description}
      <button onclick="deleteTask(${task.id})">Delete</button>
      <button onclick="toggleComplete(${task.id}, ${!task.completed})">${
      task.completed ? 'Undo' : 'Complete'
    }</button>
      <button onclick="startEditTask(${task.id}, '${task.description}')">Edit</button>
    `;
    taskList.appendChild(li);
  });
};

// Add or update a task
taskForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const description = taskInput.value.trim();
  if (!description) return;

  if (editMode) {
    // Update task
    await fetch(`/api/tasks/${editTaskId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ description }),
    });
    editMode = false;
    editTaskId = null;
    taskForm.querySelector('button').textContent = 'Add Task';
  } else {
    // Add new task
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ description }),
    });
  }
  taskInput.value = '';
  loadTasks();
});

// Start editing a task
const startEditTask = (id, description) => {
  editMode = true;
  editTaskId = id;
  taskInput.value = description;
  taskForm.querySelector('button').textContent = 'Update Task';
};

// Delete a task
const deleteTask = async (id) => {
  await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
  loadTasks();
};

// Toggle task completion
const toggleComplete = async (id, completed) => {
  await fetch(`/api/tasks/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ completed }),
  });
  loadTasks();
};

// Initial load
loadTasks();
