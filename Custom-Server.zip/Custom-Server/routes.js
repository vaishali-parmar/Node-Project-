const { sendHtmlResponse, sendJsonResponse } = require('./utils');

// Define route handlers
const routes = {
  '/': {
    GET: (req, res) => {
      sendHtmlResponse(res, 200, '<h1>Welcome to the Home Page</h1>');
    },
  },
  '/about': {
    GET: (req, res) => {
      sendHtmlResponse(res, 200, '<h1>About Us</h1><p>Learn more about our custom HTTP server.</p>');
    },
  },
  '/contact': {
    GET: (req, res) => {
      sendHtmlResponse(
        res,
        200,
        '<h1>Contact Us</h1><p>Feel free to reach out at contact@example.com.</p>'
      );
    },
    POST: (req, res) => {
      let body = '';
      req.on('data', chunk => {
        body += chunk.toString();
      });
      req.on('end', () => {
        sendJsonResponse(res, 201, { message: 'Contact details received!', data: body });
      });
    },
  },
  '/404': {
    GET: (req, res) => {
      sendHtmlResponse(res, 404, '<h1>404 - Page Not Found</h1><p>The requested page does not exist.</p>');
    },
  },
};

module.exports = routes;
