const express = require('express');
const Comment = require('../models/Comment');
const Blog = require('../models/Blog');
const router = express.Router();

// Add a comment to a blog post
router.post('/add-comment/:id', async (req, res) => {
  const { content } = req.body;
  const blog = await Blog.findById(req.params.id);
  const comment = new Comment({
    content,
    author: req.user.id,
    blog: blog._id,
  });

  await comment.save();
  res.redirect(`/post/${blog._id}`);
});

module.exports = router;
