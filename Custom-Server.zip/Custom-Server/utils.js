// Utility to send an HTML response
const sendHtmlResponse = (res, statusCode, content) => {
    res.writeHead(statusCode, { 'Content-Type': 'text/html' });
    res.end(content);
  };
  
  // Utility to send a JSON response
  const sendJsonResponse = (res, statusCode, data) => {
    res.writeHead(statusCode, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data));
  };
  
  module.exports = { sendHtmlResponse, sendJsonResponse };
  