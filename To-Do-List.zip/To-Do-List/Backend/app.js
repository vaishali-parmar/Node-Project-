const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const tasksFilePath = path.join(__dirname, 'tasks.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Load tasks from file
const loadTasks = () => {
  if (fs.existsSync(tasksFilePath)) {
    return JSON.parse(fs.readFileSync(tasksFilePath, 'utf-8'));
  }
  return [];
};

// Save tasks to file
const saveTasks = (tasks) => {
  fs.writeFileSync(tasksFilePath, JSON.stringify(tasks, null, 2));
};

// API: Get all tasks
app.get('/api/tasks', (req, res) => {
  res.json(loadTasks());
});

// API: Add a new task
app.post('/api/tasks', (req, res) => {
  const tasks = loadTasks();
  const newTask = { id: Date.now(), description: req.body.description, completed: false };
  tasks.push(newTask);
  saveTasks(tasks);
  res.status(201).json(newTask);
});

// API: Update a task
app.put('/api/tasks/:id', (req, res) => {
  const tasks = loadTasks();
  const taskIndex = tasks.findIndex((task) => task.id === parseInt(req.params.id, 10));
  if (taskIndex !== -1) {
    tasks[taskIndex].description = req.body.description || tasks[taskIndex].description;
    tasks[taskIndex].completed = req.body.completed ?? tasks[taskIndex].completed;
    saveTasks(tasks);
    res.json(tasks[taskIndex]);
  } else {
    res.status(404).json({ message: 'Task not found' });
  }
});

// API: Update a task
app.put('/api/tasks/:id', (req, res) => {
  const tasks = loadTasks();
  const taskIndex = tasks.findIndex((task) => task.id === parseInt(req.params.id, 10));
  if (taskIndex !== -1) {
    tasks[taskIndex].description = req.body.description || tasks[taskIndex].description;
    tasks[taskIndex].completed = req.body.completed ?? tasks[taskIndex].completed;
    saveTasks(tasks);
    res.json(tasks[taskIndex]);
  } else {
    res.status(404).json({ message: 'Task not found' });
  }
});

// API: Delete a task
app.delete('/api/tasks/:id', (req, res) => {
  let tasks = loadTasks();
  const taskId = parseInt(req.params.id, 10);
  const initialLength = tasks.length;
  tasks = tasks.filter((task) => task.id !== taskId);
  if (tasks.length < initialLength) {
    saveTasks(tasks);
    res.json({ message: 'Task deleted' });
  } else {
    res.status(404).json({ message: 'Task not found' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
