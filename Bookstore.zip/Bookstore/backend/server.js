const express = require('express');
const bodyParser = require('body-parser');
const { Sequelize, DataTypes } = require('sequelize');  // Import Sequelize

const app = express();
const PORT = 3000;

// Initialize Sequelize with SQLite (or any database you're using)
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: 'books.db',  // Path to your SQLite database file
});

// Define the Book model
const Book = sequelize.define('Book', {
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  author: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  genre: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  price: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
});

// Middleware
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(express.static('public')); // To serve static assets like CSS

// Initialize database
sequelize.sync()  // This will create the table if it doesn't exist
  .then(() => {
    console.log('Database connected and tables synced');
  })
  .catch((error) => {
    console.error('Unable to connect to the database:', error);
  });

// Routes
app.get('/', async (req, res) => {
  const books = await Book.findAll();
  res.render('index', { books });
});

app.get('/add-book', (req, res) => {
  res.render('add-book');
});

app.post('/add-book', async (req, res) => {
  const { title, author, genre, price } = req.body;

  if (!title || !author || !genre || !price) {
    return res.status(400).send('All fields are required');
  }

  try {
    const book = await Book.create({ title, author, genre, price });
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error adding the book');
  }
});

app.get('/search', (req, res) => {
  res.render('search-book');
});

app.post('/search', async (req, res) => {
  const { title, author, genre } = req.body;
  const conditions = {};

  if (title) conditions.title = { [Sequelize.Op.like]: `%${title}%` };
  if (author) conditions.author = { [Sequelize.Op.like]: `%${author}%` };
  if (genre) conditions.genre = { [Sequelize.Op.like]: `%${genre}%` };

  try {
    const books = await Book.findAll({ where: conditions });
    if (books.length > 0) {
      res.render('index', { books });
    } else {
      res.status(404).send('No books found matching the search criteria');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Error fetching books');
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
