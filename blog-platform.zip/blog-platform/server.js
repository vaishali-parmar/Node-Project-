const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const User = require('./models/User');
const Blog = require('./models/Blog');
const Comment = require('./models/Comment');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));  // Static folder for CSS
app.set('view engine', 'ejs');

// Connect to MongoDB
mongoose.connect('mongodb+srv://dineshraj9724226506:3NNXe1JCkjrGmOMU@pharmacare.fmzratl.mongodb.net/?retryWrites=true&w=majority&appName=PharmaCare', {
  // useNewUrlParser: true,
  // useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((err) => {
  console.log('Error connecting to MongoDB: ', err);
});

// Passport.js setup
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
}));

app.use(passport.initialize());
app.use(passport.session());

// Passport local strategy
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// Home page displaying all blogs
app.get('/', async (req, res) => {
  try {
    // Fetch all blogs
    const blogs = await Blog.find().populate('author', 'username');
    res.render('index', { user: req.user || null, blogs: blogs });
  } catch (err) {
    console.error('Error fetching blogs:', err);
    res.status(500).send('Error loading blogs.');
  }
});




// Create new blog post
app.get('/create-post', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  res.render('create-post');
});

// Handle form submission for new post
app.post('/create-post', async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  const { title, content } = req.body;
  const blog = new Blog({ title, content, author: req.user.id });
  try {
    await blog.save();
    res.redirect('/');
  } catch (err) {
    console.log(err);
    res.status(500).send('Error creating blog post.');
  }
});

// Edit a blog post
app.get('/edit-post/:id', async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  try {
    const blog = await Blog.findById(req.params.id);
    if (blog.author.toString() !== req.user.id.toString()) {
      return res.redirect('/');
    }
    res.render('edit-post', { blog });
  } catch (err) {
    console.log(err);
    res.status(500).send('Error fetching blog post.');
  }
});

// Handle post update
app.post('/edit-post/:id', async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  const { title, content } = req.body;
  try {
    await Blog.findByIdAndUpdate(req.params.id, { title, content });
    res.redirect('/');
  } catch (err) {
    console.log(err);
    res.status(500).send('Error updating blog post.');
  }
});

// View a single blog post with comments
app.get('/post/:id', async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id).populate('author', 'username').exec();
    const comments = await Comment.find({ blog: blog._id }).populate('author', 'username').exec();
    res.render('post', { blog, comments });
  } catch (err) {
    console.log(err);
    res.status(500).send('Error fetching blog post.');
  }
});

// Add a comment to a post
app.post('/add-comment/:id', async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  const { content } = req.body;
  const blog = await Blog.findById(req.params.id);
  const comment = new Comment({
    content,
    author: req.user.id,
    blog: blog._id,
  });
  try {
    await comment.save();
    res.redirect(`/post/${blog._id}`);
  } catch (err) {
    console.log(err);
    res.status(500).send('Error adding comment.');
  }
});

// User registration page
app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', (req, res) => {
  const { username, email, password, confirmPassword } = req.body;

  // Validate and register user (e.g., save to database)
  if (password !== confirmPassword) {
      return res.send("Passwords do not match.");
  }

  // Proceed with registration (e.g., hash the password and save to DB)
  const newUser = new User({
      username,
      email,
      password: hashedPassword,  // Ensure you hash the password before saving
  });

  newUser.save()
      .then(() => {
          res.redirect('/login');
      })
      .catch((err) => {
          console.error(err);
          res.send("Error registering user.");
      });
});


// User login page
app.get('/login', (req, res) => {
  res.render('login');
});

// Handle login form submission
app.post('/login', passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/login',
}));

// User logout
app.get('/logout', (req, res) => {
  req.logout((err) => {
      if (err) {
          return next(err);
      }
      res.redirect('/');
  });
});


// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});





