const express = require('express');
const { register, login } = require('../controllers/authController');

const router = express.Router();

// Render Login Page
router.get('/login', (req, res) => {
    res.render('auth/login');
});

// Render Register Page
router.get('/register', (req, res) => {
    res.render('auth/register');
});

// Handle Registration
router.post('/register', register);

// Handle Login
router.post('/login', login);

module.exports = router;
